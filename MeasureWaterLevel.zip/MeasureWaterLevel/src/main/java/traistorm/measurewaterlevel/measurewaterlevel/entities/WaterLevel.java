package traistorm.measurewaterlevel.measurewaterlevel.entities;

public class WaterLevel {
    private Long id;
    private String value;
    private Long time;
    private String dateTime;

    public WaterLevel() {
    }

    public WaterLevel(Long id, String value, Long time, String dateTime) {
        this.id = id;
        this.value = value;
        this.time = time;
        this.dateTime = dateTime;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }
}
