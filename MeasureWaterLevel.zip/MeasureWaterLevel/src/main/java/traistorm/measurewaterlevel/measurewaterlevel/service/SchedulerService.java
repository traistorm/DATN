package traistorm.measurewaterlevel.measurewaterlevel.service;

import javafx.application.Platform;
import traistorm.measurewaterlevel.measurewaterlevel.Utils;
import traistorm.measurewaterlevel.measurewaterlevel.config.AppConstant;
import traistorm.measurewaterlevel.measurewaterlevel.entities.WaterLevel;

import java.sql.*;
import java.util.*;

public class SchedulerService {
    public SchedulerService() {
        scheduleDailyTask();
    }
    // Lên lịch cho các task
    public static void scheduleDailyTask() {
        Timer timer = new Timer();

        // Lấy thời gian hiện tại
        Calendar currentTime = Calendar.getInstance();
        int currentHour = currentTime.get(Calendar.HOUR_OF_DAY);
        int currentMinute = currentTime.get(Calendar.MINUTE);

        // Tính thời gian đến 20h hàng ngày
        int delayToMorning = 0;
        if (currentHour < 20 || (currentHour == 20 && currentMinute == 0)) {
            delayToMorning = (20 - currentHour) * 60 - currentMinute;
        } else {
            delayToMorning = (20 - currentHour + 24) * 60 - currentMinute;
        }
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                sendEmailDailyReport();
            }
        }, delayToMorning * 60 * 1000, 24 * 60 * 60 * 1000);
    }

    // Gửi Email báo cáo hàng ngày
    private static void sendEmailDailyReport() {
        try {
            // Thực thi truy vấn INSERT
            Connection conn = DriverManager.getConnection(AppConstant.JDBC_URL, AppConstant.DATABASE_USERNAME, AppConstant.DATABASE_PASSWORD);
            Statement stmt = conn.createStatement();
            String query = "select * from water_level where time >= " + Utils.getStartTimeOfDay()
                    + " and time <= " + Utils.getLastTimeOfDay()
                    + " and value <> -1";
            ResultSet resultSet = stmt.executeQuery(query);
            List<WaterLevel> waterLevels = new ArrayList<>();
            Float minValue = 0F, maxValue = 0F;
            boolean firstSet = true;
            while (resultSet.next()) {
                WaterLevel waterLevel = new WaterLevel();
                waterLevel.setId(resultSet.getLong("id"));
                waterLevel.setValue(resultSet.getString("value"));
                waterLevel.setTime(resultSet.getLong("time"));
                waterLevels.add(waterLevel);
                if (firstSet) {
                    minValue = Float.parseFloat(waterLevel.getValue());
                    maxValue = Float.parseFloat(waterLevel.getValue());
                    firstSet = false;
                }
                if (minValue > Float.parseFloat(waterLevel.getValue())) {
                    minValue = Float.parseFloat(waterLevel.getValue());
                }
                if (maxValue < Float.parseFloat(waterLevel.getValue())) {
                    maxValue = Float.parseFloat(waterLevel.getValue());
                }

            }
            Float finalMaxValue = maxValue * 5;
            Float finalMinValue = minValue * 5;
            resultSet.close();
            //System.out.println("Đã lưu trữ thông điệp vào cơ sở dữ liệu");
            MailService.sendEmailDailyReport(finalMinValue, finalMaxValue);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
