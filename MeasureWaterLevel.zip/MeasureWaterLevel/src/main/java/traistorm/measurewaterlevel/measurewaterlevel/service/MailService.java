package traistorm.measurewaterlevel.measurewaterlevel.service;

import traistorm.measurewaterlevel.measurewaterlevel.config.AppConstant;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Calendar;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;

public class MailService {
    public static void sendEmail() {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(AppConstant.USERNAME_GMAIL, AppConstant.PASSWORD_APP_GMAIL);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(AppConstant.USERNAME_GMAIL));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse("cuongcaohuy@gmail.com"));
            message.setSubject("JavaFX Email Example");
            message.setText("This is a JavaFX email example using JavaMail.");

            Transport.send(message);

            System.out.println("Email sent successfully!");

        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
    public static void sendEmailDailyReport(Float minValue, Float maxValue) {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(AppConstant.USERNAME_GMAIL, AppConstant.PASSWORD_APP_GMAIL);
            }
        });

        try {
            String subject = "EMAIL BÁO CÁO HÀNG NGÀY";
            String messageTextHighestWaterLevel = "Mực nước cao nhất trong ngày: " + maxValue;
            String messageTextLowestWaterLevel = "Mực nước thấp nhất trong ngày: " + minValue;
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(AppConstant.USERNAME_GMAIL));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse("cuongcaohuy@gmail.com"));
            String htmlMessage = "<html><body><h1 style=\"color:blue\">" + subject + "</h1>"
                    + "<p>" + messageTextHighestWaterLevel + "</p>"
                    + "<br>"
                    + "<p>" + messageTextLowestWaterLevel + "</p>"
                    + "<br>"
                    + "<p>" + "Chúc một ngày tốt lành!" + "</p>"
                    + "</body></html>";

            message.setContent(htmlMessage, "text/html; charset=utf-8");
            Transport.send(message);

            System.out.println("Email sent successfully!");

        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
    public static void sendWarningEmail() {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(AppConstant.USERNAME_GMAIL, AppConstant.PASSWORD_APP_GMAIL);
            }
        });

        try {
            String subject = "EMAIL CẢNH BÁO MỰC NƯỚC";
            String messageText = "Cảnh báo! Mực nước đã vượt quá giới hạn cho phép";
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(AppConstant.USERNAME_GMAIL));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse("cuongcaohuy@gmail.com"));
            String htmlMessage = "<html><body><h1 style=\"color:red\">" + subject + "</h1>"
                    + "<p>" + messageText + "</p></body></html>";

            message.setContent(htmlMessage, "text/html; charset=utf-8");
            Transport.send(message);

            System.out.println("Email sent successfully!");

        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
}

