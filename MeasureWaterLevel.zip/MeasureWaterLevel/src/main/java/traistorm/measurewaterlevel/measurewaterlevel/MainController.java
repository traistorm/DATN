package traistorm.measurewaterlevel.measurewaterlevel;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.concurrent.Task;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import org.eclipse.paho.client.mqttv3.*;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import traistorm.measurewaterlevel.measurewaterlevel.config.AppConstant;
import traistorm.measurewaterlevel.measurewaterlevel.entities.WaterLevel;
import traistorm.measurewaterlevel.measurewaterlevel.service.MailService;
import traistorm.measurewaterlevel.measurewaterlevel.service.SchedulerService;

import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

public class MainController extends Application {
    // Send Eamil warning
    private boolean isSendWarningEmail = false;
    private Long lastTimeSendWarningEmail = 0L;
    private Long timeForNextSendWarningEmail = 5 * 60 * 60 * 1000L; // Thời gian giữa hai lần gửi (5H một lần)
    // Water info
    Label currentWaterLevelLabel = new Label("MỰC NƯỚC HIỆN TẠI : Chưa xác định");
    Label highestWaterLevelLabel = new Label("MỨC NƯỚC CAO NHẤT : 1");
    Label lowestWaterLevelLabel = new Label("MỨC NƯỚC THẤP NHẤT : 1");
    Label statusApp = new Label("Trạng thái : Đang cập nhật");
    private String showHighestAndLowestLevelMode = "HIGHEST_IN_DAY";
    private static final String HIGHEST_IN_DAY = "HIGHEST_IN_DAY";
    private static final String HIGHEST_IN_WEEK = "HIGHEST_IN_WEEK";
    private static final String HIGHEST_IN_MONTH = "HIGHEST_IN_MONTH";
    private static final String HIGHEST_IN_YEAR = "HIGHEST_IN_YEAR";

    // Database
    private String username = "root";
    private String password = "mancity1st";

    // Kết nối tới cơ sở dữ liệu
    Connection conn;
    Statement stmt;

    // Mqtt

    String broker = "tcp://broker.emqx.io:1883";
    String clientId = "traistormID";
    String topic = "traistorm";
    MqttClient client;

    // Table view
    private int currentPage = 0;
    private LocalDate datePickerViewRecord = LocalDate.now();
    List<WaterLevel> waterLevels = new ArrayList<>();
    // Tạo TableView
    TableView<WaterLevel> tableView = new TableView<>();

    public MainController() throws MqttException {
    }

    @Override
    public void start(Stage stage) throws IOException, SQLException {
        SchedulerService schedulerService = new SchedulerService();
        conn = DriverManager.getConnection(AppConstant.JDBC_URL, username, password);
        stmt = conn.createStatement();

        Image image = new Image(Utils.loadFileFromPathInResource("images/water_ruler.jpg").toURI().toString());
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(200);
        imageView.setFitHeight(200);

        // Chọn mode hiển thị mực nước
        ComboBox<String> comboBox = new ComboBox<>();
        // Thêm các giá trị cho combobox
        comboBox.getItems().addAll(HIGHEST_IN_DAY, HIGHEST_IN_MONTH, HIGHEST_IN_WEEK, HIGHEST_IN_YEAR);
        comboBox.setValue(HIGHEST_IN_DAY);

        // Xử lý sự kiện khi một giá trị được chọn
        comboBox.setOnAction(e -> {
            showHighestAndLowestLevelMode = comboBox.getValue();
            // Gọi các phương thức hoặc thực hiện các thao tác cần thiết với giá trị đã chọn ở đây
            System.out.println("Giá trị đã chọn: " + showHighestAndLowestLevelMode);
        });

        statusApp.setTextFill(Color.color(0, 1, 0));
        VBox vBoxWaterLevelInfo = new VBox(currentWaterLevelLabel, highestWaterLevelLabel, lowestWaterLevelLabel, comboBox, statusApp);
        vBoxWaterLevelInfo.setSpacing(20);
        vBoxWaterLevelInfo.setAlignment(Pos.CENTER_LEFT);
        vBoxWaterLevelInfo.setPadding(new Insets(10, 10, 10, 10));
        HBox hboxWaterInfo = new HBox(imageView, vBoxWaterLevelInfo);
        hboxWaterInfo.setAlignment(Pos.CENTER);
        hboxWaterInfo.setSpacing(20);
        hboxWaterInfo.setPadding(new Insets(5, 5, 5, 5));
        hboxWaterInfo.setPrefSize(500, 100);

        Color backgroundColor = Color.rgb(223, 253, 253); // Màu đỏ
        BackgroundFill backgroundFill = new BackgroundFill(backgroundColor, CornerRadii.EMPTY, javafx.geometry.Insets.EMPTY);
        Background background = new Background(backgroundFill);
        vBoxWaterLevelInfo.setBackground(background);


        // Button show all water level
        Button showAllWaterLevelButton = new Button("Hiển thị thông tin mực nước");
        showAllWaterLevelButton.setOnAction(e -> {
            openWindowShowWaterLevelRecord();
        });
        HBox showAllWaterLevelHbox = new HBox(showAllWaterLevelButton);
        showAllWaterLevelHbox.setAlignment(Pos.CENTER);
        showAllWaterLevelHbox.setPrefSize(500, 20);

        Button button = new Button("Send mail");
        button.setOnAction(e -> {
            MailService.sendEmail();
        });

        VBox vBox = new VBox(hboxWaterInfo, showAllWaterLevelHbox, button);
        vBox.setSpacing(20);
        vBox.setPrefSize(500, 300);
        //vBox.setAlignment(Pos.CENTER);
        Scene scene = new Scene(vBox);

        stage.setOnCloseRequest((WindowEvent event) -> {
            System.exit(0);
        });

        Image icon = new Image(Utils.loadFileFromPathInResource("images/icon.png").getPath());

        // Set the application icon
        stage.getIcons().add(icon);
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();

        // Tạo Task để thực hiện việc cập nhật giá trị cho Label
        Task<Void> updateTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                while (true) {
                    updateHighestAndLowestWaterLevel();
                    System.out.println("Updating..........");
                    Thread.sleep(5000);
                }
            }
        };

        // Bắt đầu Task trong luồng giao diện chính (Application Thread)
        new Thread(updateTask).start();

        // Tạo Task để thực hiện việc reconnect to mqtt service
        Task<Void> checkMqttConnection = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                checkClientConnect();
                return null;
            }
        };

        // Bắt đầu Task trong luồng giao diện chính (Application Thread)
        new Thread(checkMqttConnection).start();

        try {
            //MqttConnectOptions connOpts = new MqttConnectOptions();
            //connOpts.setCleanSession(false); // Set clean session to false
            client = new MqttClient(broker, clientId, new MemoryPersistence());
            client.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) {
                    System.out.println("Kết nối đã mất");
                }

                @Override
                public void messageArrived(String topic, MqttMessage message) throws Exception {
                    String payload = new String(message.getPayload());
                    String[] parts = payload.split("_");
                    System.out.println("Nhận thông điệp: " + payload);
                    saveWaterLevelToDatabase(parts[0], parts[1]);
                    updateWaterLevelLabel(payload);

                    // Send warning Email
                    if (Float.parseFloat(parts[0]) < 6 && !isSendWarningEmail && (System.currentTimeMillis() - lastTimeSendWarningEmail > timeForNextSendWarningEmail)) {
                        System.out.println("Send warning email");
                        isSendWarningEmail = true;
                        sendWarningEmail();
                        lastTimeSendWarningEmail = System.currentTimeMillis();
                    }
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                    // Không sử dụng trong trường hợp subscriber
                }
            });
            client.connect();
            client.subscribe(topic);

            System.out.println("Đang lắng nghe các thông điệp từ topic: " + topic);

        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
    // Lưu thông tin mực nước vào DB
    public void saveWaterLevelToDatabase(String waterLevel, String timeMeasurement) {
        try {
            // Kết nối tới cơ sở dữ liệu
            conn = DriverManager.getConnection(AppConstant.JDBC_URL, username, password);
            stmt = conn.createStatement();

            // Thực thi truy vấn INSERT
            String sql = "INSERT INTO water_level (value, time_measurement, time) VALUES (" + waterLevel + "," + timeMeasurement + "," + System.currentTimeMillis() + ")";
            stmt.executeUpdate(sql);

            System.out.println("Đã lưu trữ thông tin mực nước vào cơ sở dữ liệu");

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {

        }
    }
    public void updateWaterLevelLabel(String payload) {
        Platform.runLater(() -> currentWaterLevelLabel.setText("Payload: " + payload));
    }
    // Cập nhật mức nước cao nhất, thấp nhất lên giao diện
    private void updateHighestAndLowestWaterLevel() {
        try {
            // Thực thi truy vấn INSERT
            String query = switch (showHighestAndLowestLevelMode) {
                case HIGHEST_IN_DAY ->
                        "select * from water_level where time >= " + Utils.getStartTimeOfDay() + " and time <= " + Utils.getLastTimeOfDay() + " and value <> -1";
                case HIGHEST_IN_WEEK ->
                        "select * from water_level where time >= " + Utils.getStartTimeOfWeek() + " and time <= " + Utils.getLastTimeOfWeek() + " and value <> -1";
                case HIGHEST_IN_MONTH ->
                        "select * from water_level where time >= " + Utils.getStartTimeOfMonth() + " and time <= " + Utils.getLastTimeOfMonth() + " and value <> -1";
                case HIGHEST_IN_YEAR ->
                        "select * from water_level where time >= " + Utils.getStartTimeOfYear() + " and time <= " + Utils.getLastTimeOfYear() + " and value <> -1";
                default -> "";
            };
            ResultSet resultSet = stmt.executeQuery(query);
            List<WaterLevel> waterLevels = new ArrayList<>();
            Float minValue = 0F, maxValue = 0F;
            boolean firstSet = true;
            while (resultSet.next()) {
                WaterLevel waterLevel = new WaterLevel();
                waterLevel.setId(resultSet.getLong("id"));
                waterLevel.setValue(resultSet.getString("value"));
                waterLevel.setTime(resultSet.getLong("time"));
                waterLevels.add(waterLevel);
                if (firstSet) {
                    minValue = Float.parseFloat(waterLevel.getValue());
                    maxValue = Float.parseFloat(waterLevel.getValue());
                    firstSet = false;
                }
                if (minValue > Float.parseFloat(waterLevel.getValue())) {
                    minValue = Float.parseFloat(waterLevel.getValue());
                }
                if (maxValue < Float.parseFloat(waterLevel.getValue())) {
                    maxValue = Float.parseFloat(waterLevel.getValue());
                }

            }
            Float finalMaxValue = maxValue;
            Float finalMinValue = minValue;
            Platform.runLater(() -> {
                lowestWaterLevelLabel.setText("MỨC NƯỚC THẤP NHẤT: " + finalMaxValue);
                highestWaterLevelLabel.setText("MỨC NƯỚC CAO NHẤT: " + finalMinValue);
            });
            resultSet.close();
            //System.out.println("Đã lưu trữ thông điệp vào cơ sở dữ liệu");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    // Mở cửa sổ hiển thị Record mực nước
    private void openWindowShowWaterLevelRecord() {
        // Tạo một DatePicker
        DatePicker datePicker = new DatePicker(LocalDate.now());
        datePicker.setOnAction(e -> {
            datePickerViewRecord = datePicker.getValue();
            loadWaterLevelRecordInDay();
            System.out.println("Ngày tháng đã chọn: " + datePickerViewRecord);
        });

        loadWaterLevelRecordInDay();

        // Tạo các cột cho TableView
        TableColumn<WaterLevel, Long> idColumn = new TableColumn<>("Id");
        idColumn.setPrefWidth(100);
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<WaterLevel, String> valueColumn = new TableColumn<>("Mực nước");
        valueColumn.setPrefWidth(200);
        valueColumn.setCellValueFactory(new PropertyValueFactory<>("value"));

        TableColumn<WaterLevel, String> timeColumn = new TableColumn<>("Thời điểm đo");
        timeColumn.setPrefWidth(200);
        timeColumn.setCellValueFactory(new PropertyValueFactory<>("dateTime"));

        // Thêm các cột vào TableView
        tableView.getColumns().addAll(idColumn, valueColumn, timeColumn);
        tableView.setPrefSize(500, 600);

        // Đặt số trang ban đầu là trang đầu tiên
        showPage(0, tableView);

        // Tạo nút "Previous" và "Next" cho phân trang
        Button previousButton = new Button("Previous");
        previousButton.setOnAction(e -> showPreviousPage(tableView));

        Button nextButton = new Button("Next");
        nextButton.setOnAction(e -> showNextPage(tableView));

        // Hiển thị TableView và nút phân trang trong cửa sổ mới
        HBox paginationBox = new HBox(previousButton, nextButton);

        VBox vBox = new VBox(tableView, datePicker, paginationBox);
        Scene newScene = new Scene(vBox, 550, 600);

        Stage waterLevelDataStage = new Stage();
        waterLevelDataStage.setTitle("Bảng dữ liệu mực nước");
        waterLevelDataStage.setScene(newScene);
        waterLevelDataStage.setResizable(false);

        // Hiển thị cửa sổ mới (chờ đóng)
        waterLevelDataStage.showAndWait();
    }
    // Hiển thị trang Record
    private void showPage(int page, TableView<WaterLevel> tableView) {
        int fromIndex = page * AppConstant.ITEM_PER_PAGE_VIEW_RECORD;
        int toIndex = Math.min(fromIndex + AppConstant.ITEM_PER_PAGE_VIEW_RECORD, waterLevels.size());

        tableView.setItems(FXCollections.observableArrayList(waterLevels.subList(fromIndex, toIndex)));
    }

    // Hiển thị trang Record tiếp theo
    private void showNextPage(TableView<WaterLevel> tableView) {
        if (currentPage < waterLevels.size() / AppConstant.ITEM_PER_PAGE_VIEW_RECORD - 1) {
            currentPage++;
            showPage(currentPage, tableView);
        }
    }

    // Hiển thị trang Record trước đó
    private void showPreviousPage(TableView<WaterLevel> tableView) {
        if (currentPage > 0) {
            currentPage--;
            showPage(currentPage, tableView);
        }
    }
    // Lấy Record về mực nước trong một ngày đã chọn
    private void loadWaterLevelRecordInDay() {
        try {
            // Kết nối tới cơ sở dữ liệu
            conn = DriverManager.getConnection(AppConstant.JDBC_URL, username, password);
            stmt = conn.createStatement();

            // Thực thi truy vấn INSERT
            Long startTime = datePickerViewRecord.atStartOfDay().atZone(ZoneId.of("Asia/Ho_Chi_Minh")).toEpochSecond() * 1000;
            Long endTime = datePickerViewRecord.atTime(23, 59, 59).atZone(ZoneId.of("Asia/Ho_Chi_Minh")).toEpochSecond() * 1000;

            String sql = "SELECT id, value, time from water_level WHERE time > " + startTime + " AND " + " time < " + endTime;
            ResultSet resultSet = stmt.executeQuery(sql);

            waterLevels = new ArrayList<>();
            while (resultSet.next()) {
                WaterLevel waterLevel = new WaterLevel();
                waterLevel.setId(resultSet.getLong("id"));
                waterLevel.setValue(resultSet.getString("value"));
                waterLevel.setTime(resultSet.getLong("time"));
                waterLevel.setDateTime(Utils.convertLongToDate(resultSet.getLong("time")));
                waterLevels.add(waterLevel);
            }
            int fromIndex = 0;
            int toIndex = Math.min(fromIndex + AppConstant.ITEM_PER_PAGE_VIEW_RECORD, waterLevels.size());
            tableView.setItems(FXCollections.observableArrayList(waterLevels.subList(fromIndex, toIndex)));
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {

        }
    }
    // Kiểm tra kết nối tới MQTT Server
    public void checkClientConnect() throws InterruptedException {
        while (true) {
            try {
                Thread.sleep(5000);
                // Send a message to check connect
                if (client != null) {
                    client.publish("A", new MqttMessage());
                }
            } catch (Exception e) {

                e.printStackTrace();
            }
            if (client != null) {
                System.out.println(client.isConnected());
                if (!client.isConnected()) {
                    Platform.runLater(() -> {
                        statusApp.setText("Trạng thái : Đã mất kết nối");
                        statusApp.setTextFill(Color.color(1, 0, 0));
                    });
                    try {
                        System.out.println("Client is disconnect! Try reconnecting...");
                        client.connect();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    System.out.println("Đang kết nối");
                    Platform.runLater(() -> {
                        statusApp.setText("Trạng thái : Đang cập nhật");
                        statusApp.setTextFill(Color.color(0, 1, 0));
                    });
                }
            }


        }

    }
    public void sendWarningEmail() {
        MailService.sendWarningEmail();
    }

    public static void main(String[] args) {
        launch();
    }
}