package traistorm.measurewaterlevel.measurewaterlevel.config;

public class AppConstant {
    public static String USERNAME_GMAIL = "playthechessvodich@gmail.com";
    public static String PASSWORD_APP_GMAIL = "cqfqjdwgghtyiyac";
    public static String JDBC_URL = "jdbc:mysql://localhost:3306/traistorm";
    public static String DATABASE_USERNAME = "root";
    public static String DATABASE_PASSWORD = "mancity1st";
    public static int ITEM_PER_PAGE_VIEW_RECORD = 20;
}