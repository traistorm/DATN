module traistorm.measurewaterlevel.measurewaterlevel {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.base;
    requires javafx.graphics;
    requires org.eclipse.paho.client.mqttv3;
    requires java.sql;
    requires java.mail;

    opens traistorm.measurewaterlevel.measurewaterlevel;
    exports traistorm.measurewaterlevel.measurewaterlevel;
    opens traistorm.measurewaterlevel.measurewaterlevel.entities;
    exports traistorm.measurewaterlevel.measurewaterlevel.entities;
}